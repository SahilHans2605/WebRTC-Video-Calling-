const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
app.use(cors());

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join-room", (roomId) => {
  socket.join(roomId);
  console.log("User joined room:", roomId);
});


  // 📤 OFFER
  socket.on("offer", ({ roomId, offer }) => {
  socket.to(roomId).emit("offer", offer);
});

  // 📤 ANSWER
socket.on("answer", ({ roomId, answer }) => {
  socket.to(roomId).emit("answer", answer);
});

  // 📤 ICE CANDIDATES
socket.on("ice-candidate", ({ roomId, candidate }) => {
  socket.to(roomId).emit("ice-candidate", candidate);
});


  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

server.listen(5000, () => {
  console.log("✅ Signaling server running on port 5000");
});
